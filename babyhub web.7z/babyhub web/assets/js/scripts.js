// Empty JS for your own code to be here

$(function(){
    //頭像個人頁面切換
    $("li.profile").click(function(){
        $("div.profile").toggle(500);
    });
});